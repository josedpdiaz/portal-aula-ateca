<?php
/**
 * API del Formulario de Asistencia — Taller Práctico Aula ATECA (26 Noviembre)
 * Ruta pública: https://fpapps.es/formulario-asistencia/api.php
 * Hoja de Google Sheets vinculada: 1-cOkFqZnIUxqqPR-RKH_6TMJ7gX7JV4Jbh_H3xwAp18
 */

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

date_default_timezone_set('Atlantic/Canary');

$dataFile = __DIR__ . '/responses-data.json';
$gasFile  = __DIR__ . '/.gas_webapp_url';
$sheetId  = '1-cOkFqZnIUxqqPR-RKH_6TMJ7gX7JV4Jbh_H3xwAp18';
$sheetUrl = 'https://docs.google.com/spreadsheets/d/' . $sheetId . '/edit';

function loadResponses(string $file): array {
    if (!file_exists($file)) {
        return [];
    }
    $raw = @file_get_contents($file);
    $parsed = json_decode((string)$raw, true);
    return is_array($parsed) ? $parsed : [];
}

function saveResponses(string $file, array $rows): bool {
    $json = json_encode($rows, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    return @file_put_contents($file, $json, LOCK_EX) !== false;
}

$responses = loadResponses($dataFile);

// Exportación directa en CSV compatible con Excel y Google Sheets (?format=csv)
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['format']) && strtolower((string)$_GET['format']) === 'csv') {
    $filename = 'Asistencia_Taller_IA_Aula_ATECA_26_Noviembre.csv';
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    $out = fopen('php://output', 'w');
    // UTF-8 BOM para que Excel y Google Sheets detecten tildes y signos de interrogación
    fwrite($out, "\xEF\xBB\xBF");
    fputcsv($out, [
        'Marca temporal',
        'Nombre y apellidos',
        '¿Confirmas tu asistencia al taller del jueves 26 de noviembre (15:30 - 16:45)?',
        '¿En qué módulo o con qué tipo de material docente tienes pensado trabajar durante el taller?',
        'Observaciones, dudas o propuestas para la sesión'
    ]);
    foreach ($responses as $r) {
        fputcsv($out, [
            $r['timestamp'] ?? '',
            $r['nombre'] ?? '',
            $r['asistencia'] ?? '',
            $r['modulo_material'] ?? '',
            $r['observaciones'] ?? ''
        ]);
    }
    fclose($out);
    exit;
}

header('Content-Type: application/json; charset=utf-8');

// GET: devolver listado de respuestas y resumen estadístico
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $attending = 0;
    $notAttending = 0;
    foreach ($responses as $r) {
        if (($r['asistencia'] ?? '') === 'Sí, asistiré') {
            $attending++;
        } elseif (($r['asistencia'] ?? '') === 'No podré asistir') {
            $notAttending++;
        }
    }
    echo json_encode([
        'ok'       => true,
        'sheetId'  => $sheetId,
        'sheetUrl' => $sheetUrl,
        'gasConfigured' => file_exists($gasFile) && trim((string)@file_get_contents($gasFile)) !== '',
        'stats'    => [
            'total'        => count($responses),
            'attending'    => $attending,
            'notAttending' => $notAttending
        ],
        'responses' => $responses
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

// POST: registrar nueva respuesta o configurar webhook de Google Sheets
$rawInput = (string)file_get_contents('php://input');
$input = json_decode($rawInput, true);
if (!is_array($input)) {
    $input = $_POST;
}

// Acción administrativa opcional: configurar URL del Web App de Google Apps Script
if (isset($input['action']) && $input['action'] === 'set_gas_url') {
    $url = isset($input['gas_url']) ? trim((string)$input['gas_url']) : '';
    if ($url !== '' && !str_starts_with($url, 'https://script.google.com/')) {
        http_response_code(400);
        echo json_encode(['ok' => false, 'error' => 'La URL debe comenzar por https://script.google.com/']);
        exit;
    }
    @file_put_contents($gasFile, $url, LOCK_EX);
    echo json_encode(['ok' => true, 'gasConfigured' => $url !== '']);
    exit;
}

$nombre        = isset($input['nombre']) ? trim((string)$input['nombre']) : '';
$asistencia    = isset($input['asistencia']) ? trim((string)$input['asistencia']) : '';
$modulo        = isset($input['modulo_material']) ? trim((string)$input['modulo_material']) : '';
$observaciones = isset($input['observaciones']) ? trim((string)$input['observaciones']) : '';

if ($nombre === '') {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'El campo "Nombre y apellidos" es obligatorio.']);
    exit;
}

if (!in_array($asistencia, ['Sí, asistiré', 'No podré asistir'], true)) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'Debes seleccionar si confirmas tu asistencia al taller.']);
    exit;
}

$timestamp = date('d/m/Y H:i:s');
$id = 'resp-' . substr(md5(uniqid('', true)), 0, 10);

$entry = [
    'id'              => $id,
    'timestamp'       => $timestamp,
    'isoTimestamp'    => date('c'),
    'nombre'          => $nombre,
    'asistencia'      => $asistencia,
    'modulo_material' => $modulo,
    'observaciones'   => $observaciones
];

// Si el mismo docente vuelve a enviar el formulario, actualizamos su respuesta o la añadimos
$updated = false;
foreach ($responses as $idx => $existing) {
    if (isset($existing['nombre']) && mb_strtolower(trim($existing['nombre'])) === mb_strtolower($nombre)) {
        $entry['id'] = $existing['id'] ?? $id;
        $responses[$idx] = $entry;
        $updated = true;
        break;
    }
}
if (!$updated) {
    array_unshift($responses, $entry);
}

if (!saveResponses($dataFile, $responses)) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => 'No se pudo guardar la respuesta en el servidor.']);
    exit;
}

// Reenviar automáticamente a Google Sheets si hay conector GAS configurado
$syncedToSheets = false;
if (file_exists($gasFile)) {
    $gasUrl = trim((string)@file_get_contents($gasFile));
    if ($gasUrl !== '') {
        $ctx = stream_context_create([
            'http' => [
                'method'  => 'POST',
                'timeout' => 8,
                'header'  => "Content-Type: application/json\r\n",
                'content' => json_encode([
                    'sheetId' => $sheetId,
                    'action'  => $updated ? 'update' : 'append',
                    'row'     => [
                        $entry['timestamp'],
                        $entry['nombre'],
                        $entry['asistencia'],
                        $entry['modulo_material'],
                        $entry['observaciones']
                    ],
                    'entry'   => $entry
                ], JSON_UNESCAPED_UNICODE)
            ]
        ]);
        $res = @file_get_contents($gasUrl, false, $ctx);
        if ($res !== false) {
            $syncedToSheets = true;
        }
    }
}

echo json_encode([
    'ok'             => true,
    'action'         => $updated ? 'updated' : 'created',
    'syncedToSheets' => $syncedToSheets,
    'sheetUrl'       => $sheetUrl,
    'entry'          => $entry,
    'confirmationMessage' => '¡Gracias por confirmar! Recuerda traer tu portátil con wifi y al menos un material docente de tu módulo (PDF, Word o presentación). Nos vemos el jueves 26 de noviembre a las 15:30 h en el Aula ATECA.'
], JSON_UNESCAPED_UNICODE);
